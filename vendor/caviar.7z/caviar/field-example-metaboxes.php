<?php

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
function caviar_add_meta_box() {

	$screens = array('page' );

	foreach ( $screens as $screen ) {

		add_meta_box(
			'caviar_sectionid',
			__( 'Caviar Metabox Field Example', 'caviar_textdomain' ),
			'caviar_meta_box_callback',
			$screen
		);
	}
}

add_action( 'add_meta_boxes', 'caviar_add_meta_box' );

/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function caviar_meta_box_callback( $post ) {

	// Add a nonce field so we can check for it later.
	wp_nonce_field( 'caviar_save_meta_box_data', 'caviar_meta_box_nonce' );

	/*
	 * Use get_post_meta() to retrieve an existing value
	 * from the database and use the value for the form.
	 */
	$txtName      = get_post_meta( $post->ID, '_txtName', true );
	$txtAddress   = get_post_meta( $post->ID, '_txtAddress', true );
	$txtWebsite   = get_post_meta( $post->ID, '_txtWebsite', true );
	$chkFood      = get_post_meta( $post->ID, '_chkFood', true );
	$selHobby	  = get_post_meta( $post->ID, '_selHobby', true );
	$selTrans	  = get_post_meta( $post->ID, '_selTrans', true );
	$itemFeatures = get_post_meta( $post->ID, '_itemFeatures', true );
	$gender       = get_post_meta( $post->ID, '_gender', true );
	$colorMeta    = get_post_meta( $post->ID, '_colorMeta', true );
	$edAboutMe    = get_post_meta( $post->ID, '_edAboutMe', true );
	$selCats      = get_post_meta( $post->ID, '_selCats', true );
	$upPhoto      = get_post_meta( $post->ID, '_upPhoto', true );
	$upLicense    = get_post_meta( $post->ID, '_upLicense', true );

	// var_dump($itemFeatures);
	// var_dump($colorMeta);
	// var_dump($gender);
	$fields  = array(
		'title' => array(
			'title' => 'Feature',
			'type'  => 'text',
		),
		'desc' => array(
			'title' => 'Price',
			'type'  => 'textarea',
		),
		'pic' => array(
			'title' => 'Picture',
			'type'  => 'upload',
		),
		'featured' => array(
			'title' => 'Featured',
			'type'  => 'checkbox',
			'options' => array(
				'1' => 'Yes',
				'2' => 'No',
				'3' => 'Undecided',
			)
		)    
	);

	$fieldControl = new Field_Controls();
	// $fieldControl->upload('Photo', 'upPhoto', array('name' => 'upPhoto', 'value' => $upPhoto, 'class' => 'single previewImage', 'placeholder' => __('Image URL' , 'epic-base')));
	// $fieldControl->upload('License Url', 'upLicense', array('name' => 'upLicense', 'value' => $upLicense, 'class' => 'single previewImage', 'placeholder' => __('Driving License url' , 'epic-base')));

	// $fieldControl->text('Name', 'txtName', array('value' => esc_attr( $txtName )));
	// $fieldControl->text('Website', 'txtWebsite', array('type' => 'url','value' => esc_attr( $txtWebsite )));
	// $fieldControl->textarea('Address', 'txtAddress', array('value' => $txtAddress) );
	// $fieldControl->select('Transportation?', 'selTrans', array('name' => 'selTrans', 'value' => $selTrans, 'class' => 'widefat'), array('car' => 'Car', 'bike' => 'Bike', 'train' => 'Train') );
	// $fieldControl->select('Hobby?', 'selHobby', array('name' => 'selHobby', 'multiple' => 'multiple', 'value' => $selHobby, 'class' => 'widefat'), array('Out Door' => array('football' => 'Football', 'basketball' => 'Basketball', 'tennis' => 'Tennis', 'swimming' => 'Swimming'), 'Indoor' => array('reading' => 'Reading', 'writing' => 'Writing'), 'Extreme' => array('basejump' => 'Base Jumping', 'surving' => 'Surving', 'diving' => 'Diving')) );
 	$fieldControl->checkbox('Food?', 'chkFood', array('name' => 'chkFood', 'value' => $chkFood, 'class' => 'widefat'), array('fruit' => 'Fruit', 'vegetable' => 'Vegetable', 'bread' => 'Bread') );
 	// $fieldControl->radio('Gender', 'gender', array('name' => 'gender', 'value' => $gender), array('male' => 'Male', 'female' => 'Female', 'other' => 'Other'));

 // 	$fieldControl->colorpicker('Fav Color', 'colorMeta', array('class' => 'widefat', 'value' => $colorMeta));
 // 	$fieldControl->editor('About me', 'edAboutMe', array('value' => $edAboutMe), array('textarea_rows' => '5'));
 	
 	// $fieldControl->taxonomy('Category', 'selCats', array('name' =>  'selCats', 'type' => 'select', 'value' => $selCats), 'post_tag', '');
 	$fieldControl->repeaterField('Repeated Feature', 'itemFeatures', array('name' => 'itemFeatures', 'value' => $itemFeatures), $fields);
 	?>

<?php
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function caviar_save_meta_box_data( $post_id ) {
	// Sanitize user input.
	$txtname      = sanitize_text_field( $_POST['txtName'] );
	$txtAddress   = $_POST['txtAddress'];
	$selTrans     = $_POST['selTrans'];
	$txtWebsite   = sanitize_text_field( $_POST['txtWebsite'] );
	$chkFood      = $_POST['chkFood'];
	$itemFeatures = $_POST['itemFeatures'];
	$gender       = $_POST['gender'];
	$edAboutMe    = $_POST['edAboutMe'];

	$features = array();

	// Update the meta field in the database.
	update_post_meta( $post_id, '_txtName', $txtname );
	update_post_meta( $post_id, '_txtAddress', $txtAddress );
	update_post_meta( $post_id, '_selTrans', $selTrans );
	update_post_meta( $post_id, '_txtWebsite', $txtWebsite );
	update_post_meta( $post_id, '_chkFood', $chkFood );
	update_post_meta( $post_id, '_gender', $gender );
	update_post_meta( $post_id, '_colorMeta', $_POST['colorMeta'] );
	update_post_meta( $post_id, '_selHobby', $_POST['selHobby'] );
	update_post_meta( $post_id, '_edAboutMe', $edAboutMe );
	update_post_meta( $post_id, '_selCats', $_POST['selCats'] );
	update_post_meta( $post_id, '_upPhoto', $_POST['upPhoto'] );
	update_post_meta( $post_id, '_upLicense', $_POST['upLicense'] );

	// var_dump($itemFeatures);
	if ( isset( $itemFeatures ) )
	{
		foreach ( $itemFeatures as $feature )
		{
			if ( '' !== trim( $feature['title'] ) )
				$features[] = $feature;
		}
	}

	update_post_meta( $post_id, '_itemFeatures', $features );
}

add_action( 'save_post', 'caviar_save_meta_box_data' );